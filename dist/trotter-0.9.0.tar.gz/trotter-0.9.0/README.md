![](https://bitbucket.org/ram6ler/python_trotter/wiki/trotter_py.png)

Welcome to _trotter_, a set of Python 3 class definitions that simplify working with arrangements commonly encountered in combinatorics such as combinations and permutations.

Please see the [trotter wiki](https://bitbucket.org/ram6ler/python_trotter/wiki/About.md) for more information.

 